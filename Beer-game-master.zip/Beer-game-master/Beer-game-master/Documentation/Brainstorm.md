# Brainstorm
1. Player can use analog stick on gamepad to emulate arcade joysticks.
1. We want to come up with a mouse and keyboard control scheme for players without gamepads.
1. Could work as a mobile game? What would the controls?
1. How can I customize the theme? The game I would like to create is not about ice cold beer. 
1. David wants us to make a first playabvle protoype as a top priority! Before we get carried away with the story and stuff...  
## References
[Wikipedia entry for Ice Cold Beer arcade game](https://en.wikipedia.org/wiki/Ice_Cold_Beer)
- [Ice Cold Beer Gameplay](https://youtu.be/EI7gmyuSR80)
- [Ice Cold Beer Gameplay (interface)](https://youtu.be/-uOwARIPkDc)
